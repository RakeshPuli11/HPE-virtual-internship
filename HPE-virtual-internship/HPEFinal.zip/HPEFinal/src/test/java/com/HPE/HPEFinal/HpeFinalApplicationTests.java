package com.HPE.HPEFinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HpeFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
